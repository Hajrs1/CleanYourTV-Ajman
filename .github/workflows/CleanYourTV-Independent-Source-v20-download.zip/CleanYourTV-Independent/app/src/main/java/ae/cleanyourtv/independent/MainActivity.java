package ae.cleanyourtv.independent;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Standalone Android TV dashboard. Live values are shown only when fetched successfully. */
public class MainActivity extends Activity {
    private final int bg = Color.rgb(12,19,27), panel = Color.rgb(27,39,49), gold = Color.rgb(231,184,92);
    private final Handler handler = new Handler();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView clockView, dateView, weatherValue, weatherExtra, statusView, prayerSummary, barcelonaSummary;
    private TextView sectionContent;
    private android.webkit.WebView prayerWebView;
    private volatile String weatherSnapshot = "الطقس: جارٍ التحديث";
    private LinearLayout activePage;
    private String currentSection = "home";
    private LinearLayout dashboard;
    private LinearLayout root;
    private final Runnable ticker = new Runnable() { @Override public void run() { updateClock(); handler.postDelayed(this, 1000); } };
    private final Runnable screensaverTicker = new Runnable() {
        @Override public void run() {
            if ("screensaver".equals(currentSection) && activePage != null && activePage.getChildCount() >= 2) {
                TextView big = (TextView) activePage.getChildAt(0);
                TextView info = (TextView) activePage.getChildAt(1);
                big.setText(clockView.getText()+"\n"+dateView.getText());
                info.setText(weatherSnapshot);
                handler.postDelayed(this, 1000);
            }
        }
    };
    private final Runnable idleScreensaver = new Runnable() {
        @Override public void run() {
            if (!isFinishing() && !currentSection.equals("screensaver")) openSection("screensaver");
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        render(); updateClock(); handler.post(ticker); resetIdleTimer(); loadWeather();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentSection.equals("home")) loadWeather(); handler.postDelayed(this, 30 * 60 * 1000); } }, 30 * 60 * 1000);
    }
    @Override protected void onDestroy() { handler.removeCallbacks(ticker); handler.removeCallbacks(idleScreensaver); handler.removeCallbacks(screensaverTicker); if (prayerWebView != null) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; } io.shutdownNow(); super.onDestroy(); }

    @Override public void onUserInteraction() {
        super.onUserInteraction();
        // Any remote interaction wakes the dashboard from the screensaver.
        if ("screensaver".equals(currentSection)) showDashboard();
        else resetIdleTimer();
    }

    private void resetIdleTimer() { handler.removeCallbacks(idleScreensaver); if (!currentSection.equals("screensaver")) handler.postDelayed(idleScreensaver, 3 * 60 * 1000); }

    private void render() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(38,22,38,22); root.setBackgroundColor(bg); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = text("CleanYourTV", 29, gold, true); top.addView(brand, new LinearLayout.LayoutParams(0,-2,1));
        clockView = text("--:--", 34, Color.WHITE, true); clockView.setGravity(Gravity.CENTER); top.addView(clockView);
        root.addView(top);
        dateView = text("", 17, Color.LTGRAY, false); dateView.setPadding(0,5,0,14); root.addView(dateView);

        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); row1.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout weather = card(row1, "الطقس في عجمان", "جارٍ تحميل حالة الطقس…", "weather");
        weatherValue = (TextView) weather.getChildAt(1);
        weatherExtra = text("", 14, Color.LTGRAY, false); weather.addView(weatherExtra);
        LinearLayout prayerCard = card(row1, "مواقيت الصلاة", "موقع الهيئة الرسمي", "prayer");
        prayerSummary = (TextView) prayerCard.getChildAt(1);
        LinearLayout barcelonaCard = card(row1, "برشلونة", "جارٍ تجهيز بيانات الفريق…", "barcelona");
        barcelonaSummary = (TextView) barcelonaCard.getChildAt(1);
        root.addView(row1, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL);
        card(row2, "أذكار وأحاديث", "محتوى نصي فقط", "adhkar");
        card(row2, "آيات قرآنية", "عرض نصي دون تلاوة صوتية", "quran");
        card(row2, "شاشة التوقف", "ساعة وتاريخ ومعلومات اليوم", "screensaver");
        root.addView(row2, new LinearLayout.LayoutParams(-1,0,1));
        dashboard = root;
        statusView = text("", 12, Color.GRAY, false); statusView.setPadding(0,10,0,0); root.addView(statusView);
        setContentView(root);
        if (row1.getChildCount() > 0) row1.getChildAt(0).requestFocus();
        loadBarcelona();
    }

    private LinearLayout card(LinearLayout row, String title, String body, String section) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_VERTICAL); c.setPadding(20,16,20,16); c.setBackgroundColor(panel); c.setFocusable(true); c.setFocusableInTouchMode(true);
        c.setForeground(getDrawable(android.R.drawable.list_selector_background));
        c.setNextFocusLeftId(View.NO_ID); c.setNextFocusRightId(View.NO_ID);
        c.setOnClickListener(v -> openSection(section));
        TextView titleView=text(title,21,gold,true); titleView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView bodyView=text(body,16,Color.WHITE,false); bodyView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        c.setContentDescription(title + ". " + body); c.addView(titleView); c.addView(bodyView);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1,1); p.setMargins(7,8,7,8); row.addView(c,p); return c;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && "prayer".equals(currentSection) && prayerWebView != null && prayerWebView.canGoBack()) { prayerWebView.goBack(); return true; }
        if (keyCode == KeyEvent.KEYCODE_BACK && !currentSection.equals("home")) { showDashboard(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    private void openSection(String section) {
        if (prayerWebView != null && !"prayer".equals(section)) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; }
        currentSection = section;
        handler.removeCallbacks(idleScreensaver);
        handler.removeCallbacks(screensaverTicker);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(54,34,54,34); page.setBackgroundColor(bg); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String title = ""; String body = "";
        switch(section) {
            case "weather": title="الطقس في عجمان"; body="جارٍ تحميل حالة الطقس…"; break;
            case "prayer": title="مواقيت الصلاة"; body="افتح صفحة مواقيت الصلاة الرسمية للهيئة."; break;
            case "barcelona": title="برشلونة"; body="جارٍ تحميل مباريات ونتائج برشلونة…"; break;
            case "adhkar": title="أذكار وأحاديث"; body="أذكار الصباح والمساء\n\nسُبْحَانَ اللَّهِ وَبِحَمْدِهِ. (١٠٠ مرة)\n\nأَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.\n\nاللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّد.\n\nقال رسول الله ﷺ: «الكلمة الطيبة صدقة». متفق عليه."; break;
            case "quran": title="آيات قرآنية"; body="بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n﴿اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ﴾\n[آية الكرسي — البقرة: ٢٥٥]\n\n﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾\n[الشرح: ٥–٦]\n\n﴿وَهُوَ مَعَكُمْ أَيْنَ مَا كُنْتُمْ﴾ [الحديد: ٤]"; break;
            case "screensaver": title="شاشة التوقف"; body="الوقت والتاريخ الهجري"; break;
        }
        // Prayer timings are shown from the UAE Authority's own live website; never substitute
        // calculated or third-party timings and never label them as official.
        if (section.equals("prayer")) {
            TextView heading=text(title,32,gold,true);
            heading.setPadding(0,0,0,10);
            page.addView(heading);
            TextView source=text("المصدر الرسمي: الهيئة العامة للشؤون الإسلامية والأوقاف والزكاة",16,Color.LTGRAY,false);
            source.setPadding(0,0,0,12);
            page.addView(source);
            prayerWebView = new android.webkit.WebView(this);
            prayerWebView.setBackgroundColor(Color.WHITE);
            prayerWebView.getSettings().setJavaScriptEnabled(true);
            prayerWebView.getSettings().setDomStorageEnabled(true);
            prayerWebView.getSettings().setAllowFileAccess(false);
            prayerWebView.getSettings().setAllowContentAccess(false);
            prayerWebView.setWebViewClient(new android.webkit.WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
                    String host = request.getUrl().getHost();
                    // Keep navigation inside the official UAE authority website only.
                    return host == null || !(host.equals("awqaf.gov.ae") || host.endsWith(".awqaf.gov.ae"));
                }
                @Override public void onReceivedError(android.webkit.WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                    if (request.isForMainFrame()) view.loadDataWithBaseURL(null,
                        "<meta charset='utf-8'><div dir='rtl' style='font-family:sans-serif;padding:32px;text-align:center;color:#222'><h2>تعذر تحميل موقع الهيئة</h2><p>تحقق من اتصال الإنترنت ثم اضغط تحديث.</p></div>",
                        "text/html", "UTF-8", null);
                }
            });
            prayerWebView.setFocusable(true);
            prayerWebView.loadUrl("https://www.awqaf.gov.ae/?lang=ar");
            page.addView(prayerWebView,new LinearLayout.LayoutParams(-1,0,1));
            TextView refreshPrayer=text("تحديث موقع الهيئة",16,Color.WHITE,true);
            refreshPrayer.setFocusable(true); refreshPrayer.setPadding(16,10,16,10); refreshPrayer.setBackgroundColor(panel);
            refreshPrayer.setOnClickListener(v -> prayerWebView.reload());
            page.addView(refreshPrayer);
            refreshPrayer.setFocusable(true);
            TextView back=text("اضغط زر الرجوع للعودة إلى القائمة الرئيسية",16,gold,false);
            page.addView(back);
            setContentView(page);
            resetIdleTimer();
            return;
        }
        TextView heading=text(title,32,gold,true); heading.setPadding(0,0,0,24); page.addView(heading);
        sectionContent=text(body,22,Color.WHITE,false); sectionContent.setGravity(Gravity.TOP|Gravity.RIGHT); sectionContent.setLineSpacing(12,1f); sectionContent.setPadding(0,10,0,10); android.widget.ScrollView scroll=new android.widget.ScrollView(this); scroll.addView(sectionContent); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); activePage=page;
        if(section.equals("screensaver")) {
            page.removeAllViews();
            page.setGravity(Gravity.CENTER);
            TextView big=text("",58,Color.WHITE,true); big.setGravity(Gravity.CENTER);
            TextView info=text(weatherSnapshot,20,Color.LTGRAY,false); info.setGravity(Gravity.CENTER);
            page.addView(big,new LinearLayout.LayoutParams(-1,0,4));
            page.addView(info,new LinearLayout.LayoutParams(-1,0,1));
            handler.post(screensaverTicker);
        }
        if(section.equals("barcelona") || section.equals("weather")) { TextView refresh=text("تحديث البيانات",18,Color.WHITE,true); refresh.setFocusable(true); refresh.setPadding(18,12,18,12); refresh.setBackgroundColor(panel); refresh.setOnClickListener(v -> { if(section.equals("barcelona")) loadBarcelona(); else loadWeather(); }); page.addView(refresh); }
        TextView back=text("اضغط زر الرجوع للعودة إلى القائمة الرئيسية",16,gold,false); page.addView(back);
        setContentView(page);
        if(section.equals("barcelona")) loadBarcelona();
        if(section.equals("weather")) loadWeather();
        // Keep the 3-minute idle policy active in every section, not only on the dashboard.
        resetIdleTimer();
    }

    private void loadBarcelona() {
        io.execute(() -> {
            HttpURLConnection con=null;
            try {
                // Resolve the team from the provider, then request its next and previous fixtures.
                JSONObject teamRoot=requestJson("https://www.thesportsdb.com/api/v1/json/123/searchteams.php?t=Barcelona");
                org.json.JSONArray teams=teamRoot.optJSONArray("teams");
                if(teams==null || teams.length()==0) throw new Exception("الفريق غير متاح من المصدر");
                String teamId="";
                // Avoid accidentally selecting another club whose name contains Barcelona.
                for(int i=0;i<teams.length();i++) {
                    JSONObject candidate=teams.getJSONObject(i);
                    String teamName=candidate.optString("strTeam", "").trim();
                    String league=candidate.optString("strLeague", "").trim();
                    if("FC Barcelona".equalsIgnoreCase(teamName) ||
                       ("Barcelona".equalsIgnoreCase(teamName) && league.toLowerCase(Locale.ROOT).contains("spanish"))) {
                        teamId=candidate.optString("idTeam", "");
                        break;
                    }
                }
                if(teamId.isEmpty()) throw new Exception("تعذر التحقق من فريق برشلونة المقصود");
                JSONObject next=requestJson("https://www.thesportsdb.com/api/v1/json/123/eventsnext.php?id="+teamId);
                JSONObject last=requestJson("https://www.thesportsdb.com/api/v1/json/123/eventslast.php?id="+teamId);
                StringBuilder out=new StringBuilder("المباريات القادمة\n\n");
                appendEvents(out,next.optJSONArray("events"));
                out.append("\n\nآخر النتائج\n\n");
                appendEvents(out,last.optJSONArray("results"));
                final String result=out.toString();
                runOnUiThread(() -> { if(barcelonaSummary!=null) barcelonaSummary.setText("المباريات القادمة وآخر النتائج"); if("barcelona".equals(currentSection) && sectionContent!=null) sectionContent.setText(result+"\n\nالمصدر: TheSportsDB"); });
            } catch(Exception e) {
                runOnUiThread(() -> { if(barcelonaSummary!=null) barcelonaSummary.setText("تعذر التحديث — اضغط لعرض التفاصيل"); if("barcelona".equals(currentSection) && sectionContent!=null) sectionContent.setText("تعذر جلب بيانات برشلونة حاليًا. حاول التحديث لاحقًا.\n\nالمصدر: TheSportsDB"); });
            } finally { if(con!=null)con.disconnect(); }
        });
    }

    private JSONObject requestJson(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(10000);
        try {
            BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
            StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close();
            return new JSONObject(b.toString());
        } finally { c.disconnect(); }
    }

    private void appendEvents(StringBuilder out, org.json.JSONArray events) throws Exception {
        if(events==null || events.length()==0) { out.append("لا توجد بيانات متاحة حاليًا."); return; }
        int count=Math.min(events.length(),5);
        for(int i=0;i<count;i++) {
            JSONObject e=events.getJSONObject(i);
            String home=e.optString("strHomeTeam","الفريق المضيف");
            String away=e.optString("strAwayTeam","الفريق الضيف");
            String date=e.optString("dateEvent","");
            String time=e.optString("strTime","");
            String score="";
            if(!e.isNull("intHomeScore") || !e.isNull("intAwayScore")) score="\n"+e.optString("intHomeScore","-")+" - "+e.optString("intAwayScore","-");
            out.append("• ").append(home).append("  —  ").append(away).append("\n").append(date).append("  ").append(time).append(score).append("\n\n");
        }
    }

    private void showDashboard() {
        if (prayerWebView != null) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; }
        currentSection="home";
        handler.removeCallbacks(screensaverTicker);
        setContentView(dashboard);
        resetIdleTimer();
        View first = dashboard.getChildAt(1);
        if (first instanceof LinearLayout && ((LinearLayout) first).getChildCount() > 0)
            ((LinearLayout) first).getChildAt(0).requestFocus();
    }

    private TextView text(String s,int size,int color,boolean bold) { TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }

    private void updateClock() {
        LocalDate now=LocalDate.now(); Locale ar=new Locale("ar", "AE");
        String time=DateTimeFormatter.ofPattern("hh:mm:ss a",ar).format(java.time.LocalTime.now());
        clockView.setText(easternDigits(time));
        String g=DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy",ar).format(now);
        String h;
        try { HijrahDate hd=HijrahDate.now(); h=DateTimeFormatter.ofPattern("d MMMM yyyy",ar).withChronology(hd.getChronology()).format(hd); }
        catch(Exception e){h="التاريخ الهجري غير متاح";}
        dateView.setText(easternDigits(g+"  •  "+h));
    }
    private String easternDigits(String s) { return s.replace('0','٠').replace('1','١').replace('2','٢').replace('3','٣').replace('4','٤').replace('5','٥').replace('6','٦').replace('7','٧').replace('8','٨').replace('9','٩'); }

    private void loadWeather() {
        io.execute(() -> {
            HttpURLConnection con=null;
            try {
                URL url=new URL("https://api.open-meteo.com/v1/forecast?latitude=25.4052&longitude=55.5136&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=Asia%2FDubai");
                con=(HttpURLConnection)url.openConnection(); con.setRequestMethod("GET"); con.setConnectTimeout(9000); con.setReadTimeout(9000);
                BufferedReader r=new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8")); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close();
                JSONObject current=new JSONObject(b.toString()).getJSONObject("current");
                final String temp=easternDigits(Math.round(current.getDouble("temperature_2m"))+"°")+" م";
                final String extra="المحسوسة "+easternDigits(Math.round(current.getDouble("apparent_temperature"))+"°")+" م  •  الرطوبة "+easternDigits(current.getInt("relative_humidity_2m")+"%")+"  •  الرياح "+easternDigits(Math.round(current.getDouble("wind_speed_10m"))+" كم/س");
                final String desc=weatherDescription(current.getInt("weather_code"));
                weatherSnapshot = "عجمان  •  " + temp + "  •  " + desc;
                runOnUiThread(() -> {
                    weatherValue.setText(temp+"  •  "+desc); weatherExtra.setText(extra);
                    statusView.setText("تم تحديث الطقس من Open-Meteo");
                    if ("weather".equals(currentSection) && sectionContent != null)
                        sectionContent.setText(temp+"  •  "+desc+"\n\n"+extra+"\n\nالمصدر: Open-Meteo");
                });
            } catch(Exception e) { runOnUiThread(() -> {
                weatherSnapshot = "الطقس في عجمان غير متاح حاليًا";
                weatherValue.setText("تعذر تحميل الطقس الآن"); weatherExtra.setText("تحقق من اتصال الإنترنت");
                if ("weather".equals(currentSection) && sectionContent != null)
                    sectionContent.setText("تعذر تحميل الطقس الآن. تحقق من اتصال الإنترنت.");
            }); }
            finally { if(con!=null)con.disconnect(); }
        });
    }
    private String weatherDescription(int c) {
        if(c==0)return "سماء صافية"; if(c<=2)return "غائم جزئيًا"; if(c==3)return "غائم"; if(c==45||c==48)return "ضباب"; if(c>=51&&c<=57)return "رذاذ"; if(c>=61&&c<=67)return "أمطار"; if(c>=71&&c<=77)return "ثلوج"; if(c>=80&&c<=82)return "زخات مطر"; if(c>=95)return "عواصف رعدية"; return "حالة جوية متغيرة";
    }
}
