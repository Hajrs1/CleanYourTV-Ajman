package ae.cleanyourtv.independent;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;
import android.widget.Toast;
import android.widget.ScrollView;
import android.widget.GridLayout;
import android.view.ViewGroup;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import java.time.OffsetDateTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import android.widget.TextView;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Standalone Android TV dashboard. Live values are shown only when fetched successfully. */
public class MainActivity extends Activity {
    private final int bg = Color.rgb(12,19,27), panel = Color.rgb(27,39,49), gold = Color.rgb(231,184,92);
    private final Handler handler = new Handler();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView clockView, dateView, weatherValue, weatherExtra, statusView, prayerSummary, barcelonaSummary;
    private TextView sectionContent, screensaverPrayerView;
    private TextView screensaverClockView, screensaverDateView, screensaverWeatherView;
    private android.webkit.WebView prayerWebView;
    private android.webkit.WebView prayerDataWebView;
    private long prayerRemainingSeconds = -1;
    private String nextPrayerLabel = "";
    private final Runnable prayerReadTicker = new Runnable() { @Override public void run() { readOfficialPrayerPage(); handler.postDelayed(this, 15000); } };
    private final Runnable prayerCountdownTicker = new Runnable() {
        @Override public void run() {
            if (prayerRemainingSeconds > 0) prayerRemainingSeconds--;
            updatePrayerCard();
            handler.postDelayed(this, 1000);
        }
    };
    private volatile String weatherSnapshot = "الطقس: جارٍ التحديث";
    private LinearLayout activePage;
    private String currentSection = "home";
    private LinearLayout dashboard;
    private LinearLayout root;
    private final Runnable ticker = new Runnable() { @Override public void run() { updateClock(); handler.postDelayed(this, 1000); } };
    // Update only the explicitly-held TextViews. Never cast layout children by index:
    // the screensaver layout begins with a LinearLayout header, not a TextView.
    private final Runnable screensaverTicker = new Runnable() {
        @Override public void run() {
            if (!"screensaver".equals(currentSection)) return;
            if (screensaverClockView != null) screensaverClockView.setText(clockView != null ? clockView.getText() : "");
            if (screensaverDateView != null) screensaverDateView.setText(dateView != null ? dateView.getText() : "");
            if (screensaverWeatherView != null) screensaverWeatherView.setText("☾  " + weatherSnapshot);
            if (screensaverPrayerView != null) updatePrayerCard();
            handler.postDelayed(this, 1000);
        }
    };
    private final Runnable idleScreensaver = new Runnable() {
        @Override public void run() {
            if (!isFinishing() && !currentSection.equals("screensaver")) openSection("screensaver");
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        render(); updateClock(); handler.post(ticker); resetIdleTimer(); loadWeather(); loadOfficialPrayerData();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentSection.equals("home")) loadWeather(); handler.postDelayed(this, 30 * 60 * 1000); } }, 30 * 60 * 1000);
    }
    @Override protected void onDestroy() { handler.removeCallbacks(ticker); handler.removeCallbacks(idleScreensaver); handler.removeCallbacks(screensaverTicker); if (prayerWebView != null) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; } if (prayerDataWebView != null) { prayerDataWebView.stopLoading(); prayerDataWebView.destroy(); prayerDataWebView = null; } handler.removeCallbacks(prayerCountdownTicker); handler.removeCallbacks(prayerReadTicker); io.shutdownNow(); super.onDestroy(); }

    @Override public void onUserInteraction() {
        super.onUserInteraction();
        // Any remote interaction wakes the dashboard from the screensaver.
        if ("screensaver".equals(currentSection)) showDashboard();
        else resetIdleTimer();
    }

    private void resetIdleTimer() { handler.removeCallbacks(idleScreensaver); if (!currentSection.equals("screensaver")) handler.postDelayed(idleScreensaver, 3 * 60 * 1000); }

    private void render() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34, 18, 34, 18);
        BitmapDrawable cinematicBg = new BitmapDrawable(getResources(), BitmapFactory.decodeResource(getResources(), R.drawable.ajman_cinematic));
        cinematicBg.setGravity(Gravity.FILL);
        root.setBackground(cinematicBg);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Header: brand, Ajman location, network/time.
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView brand = text("▣  Dalati TV", 30, gold, true);
        brand.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1.15f));
        TextView location = text("⌖  عجمان - الإمارات العربية المتحدة", 17, Color.WHITE, true);
        location.setGravity(Gravity.CENTER);
        header.addView(location, new LinearLayout.LayoutParams(0, -2, 1.5f));
        TextView network = text("●  Wi-Fi", 15, Color.LTGRAY, false);
        network.setGravity(Gravity.CENTER);
        header.addView(network, new LinearLayout.LayoutParams(-2, -2));
        clockView = text("--:--", 32, Color.WHITE, true);
        clockView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2); cp.setMargins(18,0,0,0);
        header.addView(clockView, cp);
        root.addView(header);
        dateView = text("", 15, Color.LTGRAY, false);
        dateView.setGravity(Gravity.RIGHT);
        dateView.setPadding(0, 2, 2, 10);
        root.addView(dateView);

        // Three upper information panels, matching the approved cinematic hierarchy.
        LinearLayout infoRow = new LinearLayout(this);
        infoRow.setOrientation(LinearLayout.HORIZONTAL);
        infoRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        infoRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout weather = cinematicCard(infoRow, "☾  الطقس في عجمان", "جارٍ تحميل حالة الطقس…", "weather", 0.90f);
        weatherValue = (TextView) weather.getChildAt(1);
        weatherExtra = text("تحديث مباشر", 13, Color.LTGRAY, false); weather.addView(weatherExtra);

        LinearLayout quote = cinematicCard(infoRow, "📖  حديث اليوم", "«مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ»\nرواه البخاري ومسلم", "adhkar", 1.72f);
        ((TextView)quote.getChildAt(1)).setTextSize(20);
        ((TextView)quote.getChildAt(1)).setGravity(Gravity.CENTER);

        LinearLayout barcelona = cinematicCard(infoRow, "⚽  برشلونة", "جارٍ تحميل المباراة القادمة…", "barcelona", 1.10f);
        barcelonaSummary = (TextView) barcelona.getChildAt(1);
        LinearLayout prayer = cinematicCard(infoRow, "☪  مواقيت الصلاة", "المصدر الرسمي للهيئة", "prayer", 1.10f);
        prayerSummary = (TextView) prayer.getChildAt(1);
        root.addView(infoRow, new LinearLayout.LayoutParams(-1, 0, 1.12f));

        TextView appsTitle = text("تطبيقاتك المفضلة", 17, Color.WHITE, true);
        appsTitle.setPadding(4, 8, 4, 2);
        root.addView(appsTitle);
        LinearLayout appsRow = new LinearLayout(this);
        appsRow.setId(View.generateViewId());
        appsRow.setOrientation(LinearLayout.HORIZONTAL);
        appsRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        appsRow.setGravity(Gravity.CENTER_VERTICAL);
        appTile(appsRow, "▶", "YouTube", "com.google.android.youtube", true);
        appTile(appsRow, "N", "NETFLIX", "com.netflix.ninja", false);
        appTile(appsRow, "D+", "Disney+", "com.disney.disneyplus", false);
        appTile(appsRow, "▶", "prime video", "com.amazon.amazonvideo.livingroom", false);
        appTile(appsRow, "ش", "شاهد", "com.mbc.shahid", false);
        appTile(appsRow, "▦", "التطبيقات", "apps", false);
        root.addView(appsRow, new LinearLayout.LayoutParams(-1, 0, 0.92f));

        LinearLayout nav = new LinearLayout(this);
        nav.setId(View.generateViewId());
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(8, 3, 8, 3);
        nav.setBackground(roundBackground(Color.rgb(18,31,46), gold, 1));
        navTile(nav,"⚙","الإعدادات","settings"); navTile(nav,"▤","الملفات","files");
        navTile(nav,"▣","عرض الشاشة","cast"); navTile(nav,"◉","البث المباشر","live");
        navTile(nav,"♫","الراديو","radio"); navTile(nav,"⌂","الرئيسية","home"); navTile(nav,"♪","الموسيقى","music");
        navTile(nav,"▧","الصور","photos"); navTile(nav,"▷","الفيديو","video");
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, 62); np.setMargins(0,10,0,0);
        root.addView(nav,np);
        connectVerticalFocus(infoRow,appsRow,nav);
        prayerDataWebView = new android.webkit.WebView(this);
        prayerDataWebView.setFocusable(false);
        prayerDataWebView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        prayerDataWebView.setAlpha(0.01f);
        prayerDataWebView.getSettings().setJavaScriptEnabled(true);
        prayerDataWebView.getSettings().setDomStorageEnabled(true);
        prayerDataWebView.setWebViewClient(new android.webkit.WebViewClient() {
            @Override public void onPageFinished(android.webkit.WebView view,String url) {
                readOfficialPrayerPage();
            }
        });
        root.addView(prayerDataWebView,new LinearLayout.LayoutParams(1,1));
        prayerDataWebView.loadUrl("https://www.awqaf.ae/?lang=en");
        handler.removeCallbacks(prayerReadTicker);
        handler.postDelayed(prayerReadTicker,5000);
        handler.removeCallbacks(prayerCountdownTicker);
        handler.post(prayerCountdownTicker);

        dashboard = root;
        statusView = text("", 11, Color.LTGRAY, false); statusView.setVisibility(View.GONE);
        setContentView(root);
        if (infoRow.getChildCount() > 0) infoRow.getChildAt(0).requestFocus();
        loadBarcelona();
    }

    private LinearLayout cinematicCard(LinearLayout row, String title, String body, String section, float weight) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER); c.setPadding(18,14,18,14);
        c.setBackground(roundBackground(Color.argb(184, 18, 32, 49), gold, 2));
        c.setFocusable(true); c.setFocusableInTouchMode(true); c.setId(View.generateViewId());
        c.setOnFocusChangeListener((v,hasFocus) -> c.setBackground(roundBackground(
            hasFocus?Color.argb(230,35,48,64):Color.argb(184,18,32,49),
            hasFocus?gold:Color.rgb(105,128,151), hasFocus?4:1)));
        c.setOnClickListener(v -> openSection(section));
        TextView t=text(title,20,gold,true); t.setGravity(Gravity.CENTER); c.addView(t);
        TextView b=text(body,16,Color.WHITE,false); b.setGravity(Gravity.CENTER); b.setLineSpacing(5,1f); c.addView(b);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight); p.setMargins(6,8,6,8); row.addView(c,p);
        return c;
    }

    private android.graphics.drawable.GradientDrawable roundBackground(int color, int stroke, int width) {
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(22); d.setStroke(width,stroke); return d;
    }

    private void appTile(LinearLayout row, String fallbackIcon, String label, String packageName, boolean selected) {
        LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER);
        tile.setPadding(8,7,8,7); tile.setFocusable(true); tile.setFocusableInTouchMode(true); tile.setId(View.generateViewId());
        tile.setBackground(roundBackground(selected?Color.argb(222,65,53,30):Color.argb(190,18,31,48),selected?gold:Color.rgb(105,128,151),selected?3:1));
        tile.setOnFocusChangeListener((v,hasFocus) -> tile.setBackground(roundBackground(
            hasFocus?Color.argb(220,20,34,52):Color.argb(190,18,31,48), hasFocus?gold:Color.rgb(105,128,151), hasFocus?4:1)));
        tile.setOnClickListener(v -> {
            if ("apps".equals(packageName)) openSection("apps");
            else {
                Intent launch = findLaunchIntent(packageName, label);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, "التطبيق غير مثبت أو لا يوفّر واجهة تشغيل للتلفزيون: " + label, Toast.LENGTH_LONG).show();
            }
        });
        boolean iconAdded=false;
        if (!"apps".equals(packageName)) {
            try {
                Drawable appIcon=getPackageManager().getApplicationIcon(packageName);
                ImageView image=new ImageView(this); image.setImageDrawable(appIcon);
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                image.setAdjustViewBounds(true);
                image.setPadding(0,0,0,0);
                tile.addView(image,new LinearLayout.LayoutParams(116,116));
                iconAdded=true;
            } catch (Exception ignored) { }
        }
        if (!iconAdded) {
            TextView i=text(fallbackIcon,34,selected?gold:Color.WHITE,true); i.setGravity(Gravity.CENTER);
            tile.addView(i,new LinearLayout.LayoutParams(-1,76));
        }
        tile.setContentDescription(label);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(5,4,5,4); row.addView(tile,p);
    }

    private void navTile(LinearLayout row, String icon, String label, String section) {
        LinearLayout item=new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setFocusable(true);
        item.setFocusableInTouchMode(true);
        item.setId(View.generateViewId());
        item.setContentDescription(label);
        item.setPadding(4,2,4,2);
        item.setBackground(roundBackground(Color.TRANSPARENT,Color.TRANSPARENT,1));
        item.setOnFocusChangeListener((v,hasFocus) -> item.setBackground(roundBackground(
            hasFocus?Color.argb(220,38,48,62):Color.TRANSPARENT,
            hasFocus?gold:Color.TRANSPARENT, hasFocus?3:1)));
        item.setOnClickListener(v -> { if("home".equals(section)) showDashboard(); else openSection(section); });
        TextView i=text(icon,25,gold,true); i.setGravity(Gravity.CENTER); item.addView(i);
        TextView l=text(label,11,Color.WHITE,false); l.setGravity(Gravity.CENTER); item.addView(l);
        row.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }

    private Intent findLaunchIntent(String packageName, String label) {
        PackageManager pm=getPackageManager();
        Intent leanback=new Intent(Intent.ACTION_MAIN); leanback.addCategory("android.intent.category.LEANBACK_LAUNCHER");
        Intent launcher=new Intent(Intent.ACTION_MAIN); launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        for (Intent query : new Intent[]{leanback,launcher}) {
            for (ResolveInfo ri : pm.queryIntentActivities(query,0)) {
                if (ri.activityInfo == null) continue;
                String pkg=ri.activityInfo.packageName;
                if (packageName.equals(pkg) || ri.loadLabel(pm).toString().equalsIgnoreCase(label)) {
                    Intent launch=new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(query.getCategories().iterator().next());
                    launch.setClassName(pkg,ri.activityInfo.name);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    return launch;
                }
            }
        }
        return null;
    }

    private void wireFocusRow(LinearLayout row) {
        int count=row.getChildCount();
        for(int i=0;i<count;i++) {
            View v=row.getChildAt(i);
            if(!v.isFocusable()) { v.setFocusable(true); v.setFocusableInTouchMode(true); }
            if(count>1) {
                v.setNextFocusLeftId(row.getChildAt((i-1+count)%count).getId());
                v.setNextFocusRightId(row.getChildAt((i+1)%count).getId());
            }
        }
    }

    private void connectVerticalFocus(LinearLayout upper, LinearLayout apps, LinearLayout nav) {
        if(upper.getChildCount()==0 || apps.getChildCount()==0 || nav.getChildCount()==0) return;
        for(int i=0;i<upper.getChildCount();i++) {
            View u=upper.getChildAt(i);
            View a=apps.getChildAt(Math.min(i,apps.getChildCount()-1));
            u.setNextFocusDownId(a.getId());
            a.setNextFocusUpId(u.getId());
        }
        for(int i=0;i<apps.getChildCount();i++) {
            View a=apps.getChildAt(i);
            View n=nav.getChildAt(Math.min(i,nav.getChildCount()-1));
            a.setNextFocusDownId(n.getId());
            n.setNextFocusUpId(a.getId());
        }
        wireFocusRow(upper); wireFocusRow(apps); wireFocusRow(nav);
    }

    private LinearLayout card(LinearLayout row, String title, String body, String section) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_VERTICAL); c.setPadding(20,16,20,16); c.setBackgroundColor(panel); c.setFocusable(true); c.setFocusableInTouchMode(true); c.setId(View.generateViewId());
        c.setFocusableInTouchMode(true);
        c.setOnFocusChangeListener((v,hasFocus) -> c.setBackground(roundBackground(
            hasFocus?Color.argb(235,42,47,55):panel, hasFocus?gold:Color.rgb(105,128,151), hasFocus?4:1)));
        c.setOnClickListener(v -> openSection(section));
        TextView titleView=text(title,21,gold,true); titleView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView bodyView=text(body,16,Color.WHITE,false); bodyView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        c.setContentDescription(title + ". " + body); c.addView(titleView); c.addView(bodyView);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1,1); p.setMargins(7,8,7,8); row.addView(c,p); return c;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ("screensaver".equals(currentSection) && keyCode != KeyEvent.KEYCODE_BACK) {
            showDashboard();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_BACK && "prayer".equals(currentSection) && prayerWebView != null && prayerWebView.canGoBack()) { prayerWebView.goBack(); resetIdleTimer(); return true; }
        if (keyCode == KeyEvent.KEYCODE_BACK && !currentSection.equals("home")) { showDashboard(); return true; }
        boolean handled = super.onKeyDown(keyCode, event);
        if (!"screensaver".equals(currentSection)) resetIdleTimer();
        return handled;
    }

    private void openSection(String section) {
        if (prayerWebView != null && !"prayer".equals(section)) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; }
        currentSection = section;
        screensaverClockView = null; screensaverDateView = null; screensaverWeatherView = null; screensaverPrayerView = null;
        handler.removeCallbacks(idleScreensaver);
        handler.removeCallbacks(screensaverTicker);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(54,34,54,34); page.setBackgroundColor(bg); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String title = ""; String body = "";
        switch(section) {
            case "weather": title="الطقس في عجمان"; body="جارٍ تحميل حالة الطقس…"; break;
            case "prayer": title="مواقيت الصلاة"; body="افتح صفحة مواقيت الصلاة الرسمية للهيئة."; break;
            case "barcelona": title="برشلونة"; body="جارٍ تحميل مباريات ونتائج برشلونة…"; break;
            case "adhkar": title="أذكار وأحاديث"; body="أذكار الصباح والمساء\n\nسُبْحَانَ اللَّهِ وَبِحَمْدِهِ. (١٠٠ مرة)\n\nأَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.\n\nاللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّد.\n\nقال رسول الله ﷺ: «الكلمة الطيبة صدقة». متفق عليه."; break;
            case "quran": title="آيات قرآنية"; body="بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\n﴿اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ﴾\n[آية الكرسي — البقرة: ٢٥٥]\n\n﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾\n[الشرح: ٥–٦]\n\n﴿وَهُوَ مَعَكُمْ أَيْنَ مَا كُنْتُمْ﴾ [الحديد: ٤]"; break;
            case "screensaver": title="شاشة التوقف"; body="الوقت والتاريخ الهجري"; break;
            case "apps": title="التطبيقات"; body="افتح التطبيقات من صف التطبيقات في الشاشة الرئيسية."; break;
            case "settings": title="الإعدادات"; body="إعدادات واجهة Dalati TV"; break;
            case "files": title="الملفات"; body="افتح تطبيق الملفات المثبت على التلفزيون."; break;
            case "cast": title="عرض الشاشة"; body="استخدم إعدادات العرض اللاسلكي في التلفزيون."; break;
            case "live": title="البث المباشر"; body="افتح تطبيق البث المباشر المثبت على التلفزيون."; break;
            case "radio": title="الراديو"; body="لا يوجد مصدر راديو مهيأ حاليًا."; break;
            case "music": title="الموسيقى"; body="افتح تطبيق الموسيقى المثبت على التلفزيون."; break;
            case "photos": title="الصور"; body="افتح تطبيق الصور المثبت على التلفزيون."; break;
            case "video": title="الفيديو"; body="افتح تطبيق الفيديو المثبت على التلفزيون."; break;
        }
        // Prayer timings are shown from the UAE Authority's own live website; never substitute
        // calculated or third-party timings and never label them as official.
        if (section.equals("prayer")) {
            TextView heading=text(title,32,gold,true);
            heading.setPadding(0,0,0,10);
            page.addView(heading);
            TextView source=text("المصدر الرسمي: الهيئة العامة للشؤون الإسلامية والأوقاف والزكاة",16,Color.LTGRAY,false);
            source.setPadding(0,0,0,12);
            page.addView(source);
            prayerWebView = new android.webkit.WebView(this);
            prayerWebView.setBackgroundColor(Color.WHITE);
            prayerWebView.getSettings().setJavaScriptEnabled(true);
            prayerWebView.getSettings().setDomStorageEnabled(true);
            prayerWebView.getSettings().setAllowFileAccess(false);
            prayerWebView.getSettings().setAllowContentAccess(false);
            prayerWebView.setWebViewClient(new android.webkit.WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
                    String host = request.getUrl().getHost();
                    // Keep navigation inside the official UAE authority website only.
                    return host == null || !(host.equals("awqaf.ae") || host.endsWith(".awqaf.ae"));
                }
                @Override public void onReceivedError(android.webkit.WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                    if (request.isForMainFrame()) view.loadDataWithBaseURL(null,
                        "<meta charset='utf-8'><div dir='rtl' style='font-family:sans-serif;padding:32px;text-align:center;color:#222'><h2>تعذر تحميل موقع الهيئة</h2><p>تحقق من اتصال الإنترنت ثم اضغط تحديث.</p></div>",
                        "text/html", "UTF-8", null);
                }
            });
            prayerWebView.setFocusable(true);
            prayerWebView.loadUrl("https://www.awqaf.ae/?lang=ar");
            page.addView(prayerWebView,new LinearLayout.LayoutParams(-1,0,1));
            TextView refreshPrayer=text("تحديث موقع الهيئة",16,Color.WHITE,true);
            refreshPrayer.setFocusable(true); refreshPrayer.setPadding(16,10,16,10); refreshPrayer.setBackgroundColor(panel);
            refreshPrayer.setOnClickListener(v -> prayerWebView.reload());
            page.addView(refreshPrayer);
            refreshPrayer.setFocusable(true);
            TextView back=text("اضغط زر الرجوع للعودة إلى القائمة الرئيسية",16,gold,false);
            page.addView(back);
            setContentView(page);
            resetIdleTimer();
            return;
        }
        if (section.equals("apps")) {
            page.setPadding(38,24,38,24);
            TextView appsHeading=text("التطبيقات المثبتة",30,gold,true);
            page.addView(appsHeading);
            ScrollView scrollApps=new ScrollView(this);
            GridLayout grid=new GridLayout(this);
            grid.setColumnCount(5);
            grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
            PackageManager pm=getPackageManager();
            java.util.LinkedHashMap<String,ResolveInfo> found=new java.util.LinkedHashMap<>();
            Intent leanback=new Intent(Intent.ACTION_MAIN); leanback.addCategory("android.intent.category.LEANBACK_LAUNCHER");
            Intent launcher=new Intent(Intent.ACTION_MAIN); launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            for(Intent query:new Intent[]{leanback,launcher}) {
                for(ResolveInfo ri:pm.queryIntentActivities(query,0)) {
                    if(ri.activityInfo!=null) found.put(ri.activityInfo.packageName,ri);
                }
            }
            java.util.ArrayList<ResolveInfo> appsFound=new java.util.ArrayList<>(found.values());
            java.util.Collections.sort(appsFound,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
            for(ResolveInfo ri:appsFound) {
                final String pkg=ri.activityInfo.packageName;
                final String activity=ri.activityInfo.name;
                LinearLayout tile=new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER);
                tile.setFocusable(true); tile.setFocusableInTouchMode(true); tile.setId(View.generateViewId());
                tile.setPadding(8,10,8,10);
                tile.setBackground(roundBackground(Color.argb(175,18,31,48),Color.rgb(105,128,151),1));
                tile.setOnFocusChangeListener((v,focused)->tile.setBackground(roundBackground(
                    focused?Color.argb(225,37,48,63):Color.argb(175,18,31,48),
                    focused?gold:Color.rgb(105,128,151),focused?3:1)));
                ImageView icon=new ImageView(this);
                try { icon.setImageDrawable(ri.loadIcon(pm)); } catch(Exception ignored) {}
                icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                tile.addView(icon,new LinearLayout.LayoutParams(92,92));
                TextView appName=text(ri.loadLabel(pm).toString(),13,Color.WHITE,true);
                appName.setGravity(Gravity.CENTER); appName.setMaxLines(2);
                tile.addView(appName);
                tile.setOnClickListener(v->{Intent launch=new Intent(Intent.ACTION_MAIN); launch.addCategory("android.intent.category.LEANBACK_LAUNCHER"); launch.setClassName(pkg,activity); launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try{startActivity(launch);}catch(Exception e){launch.removeCategory("android.intent.category.LEANBACK_LAUNCHER");launch.addCategory(Intent.CATEGORY_LAUNCHER);try{startActivity(launch);}catch(Exception ex){Toast.makeText(this,"تعذر فتح التطبيق",Toast.LENGTH_SHORT).show();}}});
                GridLayout.LayoutParams gp=new GridLayout.LayoutParams();
                gp.width=0; gp.height=160; gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
                gp.setMargins(7,7,7,7); grid.addView(tile,gp);
            }
            if(appsFound.isEmpty()) {
                TextView empty=text("لم يتم العثور على تطبيقات قابلة للتشغيل. تحقق من تثبيت التطبيقات.",20,Color.WHITE,false);
                empty.setGravity(Gravity.CENTER); grid.addView(empty);
            }
            scrollApps.addView(grid);
            page.addView(scrollApps,new LinearLayout.LayoutParams(-1,0,1));
            TextView back=text("اضغط زر الرجوع للعودة إلى القائمة الرئيسية",16,gold,false); page.addView(back);
            setContentView(page); resetIdleTimer(); return;
        }
        TextView heading=text(title,32,gold,true); heading.setPadding(0,0,0,24); page.addView(heading);
        sectionContent=text(body,22,Color.WHITE,false); sectionContent.setGravity(Gravity.TOP|Gravity.RIGHT); sectionContent.setLineSpacing(12,1f); sectionContent.setPadding(0,10,0,10); android.widget.ScrollView scroll=new android.widget.ScrollView(this); scroll.addView(sectionContent); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); activePage=page;
        if(section.equals("screensaver")) {
            page.removeAllViews();
            page.setPadding(34,22,34,22);
            page.setGravity(Gravity.TOP);
            page.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeResource(getResources(), R.drawable.ajman_cinematic)));
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            TextView logo = text("◉  Dalati TV", 25, gold, true);
            top.addView(logo, new LinearLayout.LayoutParams(0,-2,1));
            TextView time = text("",54,Color.WHITE,true); time.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            screensaverClockView = time;
            top.addView(time);
            page.addView(top,new LinearLayout.LayoutParams(-1,0,1.1f));
            TextView dates = text("",20,Color.WHITE,true); dates.setGravity(Gravity.RIGHT|Gravity.CENTER);
            screensaverDateView = dates;
            page.addView(dates,new LinearLayout.LayoutParams(-1,0,0.55f));
            page.addView(new View(this),new LinearLayout.LayoutParams(-1,0,2.7f));
            LinearLayout bottom = new LinearLayout(this);
            bottom.setGravity(Gravity.CENTER);
            bottom.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            bottom.setBackground(roundBackground(Color.argb(105,5,18,34),gold,2));
            TextView wifi = text("◉  Wi-Fi",18,Color.WHITE,true); wifi.setGravity(Gravity.CENTER);
            bottom.addView(wifi,new LinearLayout.LayoutParams(0,-1,1));
            TextView weather = text("☾  "+weatherSnapshot,19,Color.WHITE,true); weather.setGravity(Gravity.CENTER);
            screensaverWeatherView = weather;
            bottom.addView(weather,new LinearLayout.LayoutParams(0,-1,1.3f));
            screensaverPrayerView = text("۞  الصلاة القادمة\nجارٍ تحميل بيانات الهيئة",19,Color.WHITE,true); screensaverPrayerView.setGravity(Gravity.CENTER);
            bottom.addView(screensaverPrayerView,new LinearLayout.LayoutParams(0,-1,2.1f));
            page.addView(bottom,new LinearLayout.LayoutParams(-1,108));
            activePage=page;
            updateClock();
            if (screensaverClockView != null) screensaverClockView.setText(clockView.getText());
            if (screensaverDateView != null) screensaverDateView.setText(dateView.getText());
            if (screensaverWeatherView != null) screensaverWeatherView.setText("☾  " + weatherSnapshot);
            updatePrayerCard();
            page.setKeepScreenOn(true);
            handler.removeCallbacks(screensaverTicker);
            handler.post(screensaverTicker);
        }
        if(section.equals("barcelona") || section.equals("weather")) { TextView refresh=text("تحديث البيانات",18,Color.WHITE,true); refresh.setFocusable(true); refresh.setPadding(18,12,18,12); refresh.setBackgroundColor(panel); refresh.setOnClickListener(v -> { if(section.equals("barcelona")) loadBarcelona(); else loadWeather(); }); page.addView(refresh); }
        TextView back=text("اضغط زر الرجوع للعودة إلى القائمة الرئيسية",16,gold,false); page.addView(back);
        setContentView(page);
        if(section.equals("barcelona")) loadBarcelona();
        if(section.equals("weather")) loadWeather();
        // Keep the 3-minute idle policy active in every section, not only on the dashboard.
        resetIdleTimer();
    }

    private void readOfficialPrayerPage() {
        if (prayerDataWebView == null) return;
        prayerDataWebView.evaluateJavascript("(function(){return document.body ? document.body.innerText : '';})()", value -> {
            try {
                String body=new org.json.JSONArray("["+value+"]").getString(0);
                Pattern p=Pattern.compile("(?i)NextPrayer\\s*:\\s*(fajr|zuhr|dhuhr|asr|maghrib|isha)\\s+(\\d{1,2}:\\d{2}:\\d{2})");
                Matcher m=p.matcher(body);
                if(m.find()) {
                    nextPrayerLabel=arabicPrayerName(m.group(1));
                    String[] parts=m.group(2).split(":");
                    prayerRemainingSeconds=Integer.parseInt(parts[0])*3600L+Integer.parseInt(parts[1])*60L+Integer.parseInt(parts[2]);
                    updatePrayerCard();
                } else if(prayerSummary!=null && prayerRemainingSeconds<0) {
                    prayerSummary.setText("تعذر قراءة عدّاد الصلاة من موقع الهيئة");
                }
            } catch(Exception ignored) {
                if(prayerSummary!=null && prayerRemainingSeconds<0) prayerSummary.setText("جارٍ تحميل بيانات الهيئة الرسمية…");
            }
        });
    }

    private String arabicPrayerName(String name) {
        switch(name.toLowerCase(Locale.ROOT)) {
            case "fajr": return "الفجر";
            case "zuhr": case "dhuhr": return "الظهر";
            case "asr": return "العصر";
            case "maghrib": return "المغرب";
            case "isha": return "العشاء";
            default: return name;
        }
    }

    private void updatePrayerCard() {
        if(prayerRemainingSeconds<0) return;
        long seconds=prayerRemainingSeconds;
        String countdown=String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds%3600)/60,seconds%60);
        String value="الصلاة القادمة: "+nextPrayerLabel+"\\nالوقت المتبقي  "+countdown;
        if(prayerSummary!=null) prayerSummary.setText(value);
        if(screensaverPrayerView!=null) screensaverPrayerView.setText("۞  "+nextPrayerLabel+" • "+countdown);
    }

    private void loadBarcelona() {
        io.execute(() -> {
            HttpURLConnection con=null;
            try {
                // Resolve the team from the provider, then request its next and previous fixtures.
                JSONObject teamRoot=requestJson("https://www.thesportsdb.com/api/v1/json/123/searchteams.php?t=Barcelona");
                org.json.JSONArray teams=teamRoot.optJSONArray("teams");
                if(teams==null || teams.length()==0) throw new Exception("الفريق غير متاح من المصدر");
                String teamId="";
                // Avoid accidentally selecting another club whose name contains Barcelona.
                for(int i=0;i<teams.length();i++) {
                    JSONObject candidate=teams.getJSONObject(i);
                    String teamName=candidate.optString("strTeam", "").trim();
                    String league=candidate.optString("strLeague", "").trim();
                    if("FC Barcelona".equalsIgnoreCase(teamName) ||
                       ("Barcelona".equalsIgnoreCase(teamName) && league.toLowerCase(Locale.ROOT).contains("spanish"))) {
                        teamId=candidate.optString("idTeam", "");
                        break;
                    }
                }
                if(teamId.isEmpty()) throw new Exception("تعذر التحقق من فريق برشلونة المقصود");
                JSONObject next=requestJson("https://www.thesportsdb.com/api/v1/json/123/eventsnext.php?id="+teamId);
                org.json.JSONArray upcoming=next.optJSONArray("events");
                StringBuilder out=new StringBuilder("المباراة القادمة لبرشلونة\n\n");
                String dashboardMatch="لا توجد مباراة قادمة متاحة";
                if(upcoming==null || upcoming.length()==0) out.append("لا توجد مباراة قادمة متاحة حاليًا.");
                else {
                    JSONObject nextMatch=upcoming.getJSONObject(0);
                    appendEvents(out, new org.json.JSONArray().put(nextMatch));
                    String[] localFixture=fixtureTimeInUAE(nextMatch.optString("dateEvent",""),nextMatch.optString("strTime",""));
                    dashboardMatch=nextMatch.optString("strHomeTeam","الفريق المضيف")+" × "+nextMatch.optString("strAwayTeam","الفريق الضيف")+"\\n"+localFixture[0]+"  "+localFixture[1]+" (توقيت الإمارات)";
                }
                final String result=out.toString(); final String matchSummary=dashboardMatch;
                runOnUiThread(() -> { if(barcelonaSummary!=null) barcelonaSummary.setText("⚽ برشلونة | "+westernDigits(matchSummary.replace("\n", " • "))); if("barcelona".equals(currentSection) && sectionContent!=null) sectionContent.setText(result+"\n\nالمصدر: TheSportsDB"); });
            } catch(Exception e) {
                runOnUiThread(() -> { if(barcelonaSummary!=null) barcelonaSummary.setText("⚽ برشلونة | تعذر تحديث المباراة القادمة"); if("barcelona".equals(currentSection) && sectionContent!=null) sectionContent.setText("تعذر جلب بيانات برشلونة حاليًا. حاول التحديث لاحقًا.\n\nالمصدر: TheSportsDB"); });
            } finally { if(con!=null)con.disconnect(); }
        });
    }

    private JSONObject requestJson(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(10000);
        try {
            BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
            StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close();
            return new JSONObject(b.toString());
        } finally { c.disconnect(); }
    }

    private String[] fixtureTimeInUAE(String eventDate, String eventTime) {
        try {
            String raw=eventDate+"T"+eventTime.trim();
            if (raw.endsWith("Z")) {
                OffsetDateTime utc=OffsetDateTime.parse(raw);
                LocalDateTime uae=utc.atZoneSameInstant(ZoneId.of("Asia/Dubai")).toLocalDateTime();
                return new String[]{uae.toLocalDate().toString(), DateTimeFormatter.ofPattern("HH:mm",Locale.US).format(uae)};
            }
            if (eventTime.matches(".*[+-]\\d{2}:?\\d{2}$")) {
                OffsetDateTime parsed=OffsetDateTime.parse(raw);
                LocalDateTime uae=parsed.atZoneSameInstant(ZoneId.of("Asia/Dubai")).toLocalDateTime();
                return new String[]{uae.toLocalDate().toString(), DateTimeFormatter.ofPattern("HH:mm",Locale.US).format(uae)};
            }
            // TheSportsDB commonly supplies UTC clock values without a zone suffix.
            LocalDateTime utc=LocalDateTime.parse(eventDate+"T"+eventTime.substring(0,8));
            LocalDateTime uae=utc.atZone(ZoneId.of("UTC")).withZoneSameInstant(ZoneId.of("Asia/Dubai")).toLocalDateTime();
            return new String[]{uae.toLocalDate().toString(),DateTimeFormatter.ofPattern("HH:mm",Locale.US).format(uae)};
        } catch(Exception ex) { return new String[]{eventDate,eventTime}; }
    }

    private void appendEvents(StringBuilder out, org.json.JSONArray events) throws Exception {
        if(events==null || events.length()==0) { out.append("لا توجد بيانات متاحة حاليًا."); return; }
        int count=Math.min(events.length(),5);
        for(int i=0;i<count;i++) {
            JSONObject e=events.getJSONObject(i);
            String home=e.optString("strHomeTeam","الفريق المضيف");
            String away=e.optString("strAwayTeam","الفريق الضيف");
            String date=e.optString("dateEvent","");
            String time=e.optString("strTime","");
            String[] localFixture=fixtureTimeInUAE(date,time);
            date=localFixture[0]; time=localFixture[1];
            String score="";
            if(!e.isNull("intHomeScore") || !e.isNull("intAwayScore")) score="\n"+e.optString("intHomeScore","-")+" - "+e.optString("intAwayScore","-");
            out.append("• ").append(home).append("  —  ").append(away).append("\n").append(date).append("  ").append(time).append(score).append("\n\n");
        }
    }

    private void showDashboard() {
        if (prayerWebView != null) { prayerWebView.stopLoading(); prayerWebView.destroy(); prayerWebView = null; }
        currentSection="home";
        screensaverClockView = null; screensaverDateView = null; screensaverWeatherView = null; screensaverPrayerView = null;
        handler.removeCallbacks(screensaverTicker);
        setContentView(dashboard);
        updatePrayerCard();
        resetIdleTimer();
        View first = dashboard.getChildAt(1);
        if (first instanceof LinearLayout && ((LinearLayout) first).getChildCount() > 0)
            ((LinearLayout) first).getChildAt(0).requestFocus();
    }

    private TextView text(String s,int size,int color,boolean bold) { TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }

    private void updateClock() {
        LocalDate now=LocalDate.now(); Locale ar=new Locale("ar", "AE");
        String time=DateTimeFormatter.ofPattern("HH:mm",Locale.US).format(java.time.LocalTime.now());
        clockView.setText(westernDigits(time));
        String g=DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy",ar).format(now);
        String h;
        try { HijrahDate hd=HijrahDate.now(); h=DateTimeFormatter.ofPattern("d MMMM yyyy",ar).withChronology(hd.getChronology()).format(hd); }
        catch(Exception e){h="التاريخ الهجري غير متاح";}
        dateView.setText(westernDigits(g+"  •  "+h));
    }
    private String westernDigits(String s) {
        return s.replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4')
                .replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9')
                .replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4')
                .replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9');
    }

    private void loadWeather() {
        io.execute(() -> {
            HttpURLConnection con=null;
            try {
                URL url=new URL("https://api.open-meteo.com/v1/forecast?latitude=25.4052&longitude=55.5136&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=Asia%2FDubai");
                con=(HttpURLConnection)url.openConnection(); con.setRequestMethod("GET"); con.setConnectTimeout(9000); con.setReadTimeout(9000);
                BufferedReader r=new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8")); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close();
                JSONObject current=new JSONObject(b.toString()).getJSONObject("current");
                final String temp=westernDigits(Math.round(current.getDouble("temperature_2m"))+"°")+" م";
                final String extra="المحسوسة "+westernDigits(Math.round(current.getDouble("apparent_temperature"))+"°")+" م  •  الرطوبة "+westernDigits(current.getInt("relative_humidity_2m")+"%")+"  •  الرياح "+westernDigits(Math.round(current.getDouble("wind_speed_10m"))+" كم/س");
                final String desc=weatherDescription(current.getInt("weather_code"));
                weatherSnapshot = "عجمان  •  " + temp + "  •  " + desc;
                runOnUiThread(() -> {
                    weatherValue.setText(temp+"  •  "+desc); weatherExtra.setText(extra);
                    statusView.setText("تم تحديث الطقس من Open-Meteo");
                    if ("weather".equals(currentSection) && sectionContent != null)
                        sectionContent.setText(temp+"  •  "+desc+"\n\n"+extra+"\n\nالمصدر: Open-Meteo");
                });
            } catch(Exception e) { runOnUiThread(() -> {
                weatherSnapshot = "الطقس في عجمان غير متاح حاليًا";
                weatherValue.setText("تعذر تحميل الطقس الآن"); weatherExtra.setText("تحقق من اتصال الإنترنت");
                if ("weather".equals(currentSection) && sectionContent != null)
                    sectionContent.setText("تعذر تحميل الطقس الآن. تحقق من اتصال الإنترنت.");
            }); }
            finally { if(con!=null)con.disconnect(); }
        });
    }
    private String weatherDescription(int c) {
        if(c==0)return "سماء صافية"; if(c<=2)return "غائم جزئيًا"; if(c==3)return "غائم"; if(c==45||c==48)return "ضباب"; if(c>=51&&c<=57)return "رذاذ"; if(c>=61&&c<=67)return "أمطار"; if(c>=71&&c<=77)return "ثلوج"; if(c>=80&&c<=82)return "زخات مطر"; if(c>=95)return "عواصف رعدية"; return "حالة جوية متغيرة";
    }
}
